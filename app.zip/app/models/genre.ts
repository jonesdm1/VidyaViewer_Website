export class Genre
{
    public id: number;
    public genreName: string;
    public descriptionDetail: string;

    constructor (id: number, genreName: string, descriptionDetail: string)
    {
        this.id = id;
        this.genreName = genreName;
        this.descriptionDetail = descriptionDetail;
    }
}