import { Developer } from "./developer";
import { Game } from "./game";
import { Genre } from "./genre";
import { Rating } from "./rating";
import { Vendor } from "./vendor";

export class GamePackage
{
    public game: Game;
    public vendors: Vendor[];
    public developers: Developer[];
    public genres: Genre[];
    public rating: Rating;
    
    constructor (game: Game, vendors: Vendor[], developers: Developer[], genres: Genre[], rating: Rating)
    {
        this.game = game;
        this.vendors = vendors;
        this.developers = developers;
        this.genres = genres;
        this.rating = rating;
    }
}