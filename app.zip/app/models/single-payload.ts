export class SinglePayload<T>
{
    public item: T;
    public statusCode: number;
    public message: string;

    constructor(item: T, statusCode: number, message: string)
    {
        this.item = item;
        this.statusCode = statusCode;
        this.message = message;
    }
}