export class Developer
{
    public id: number;
    public fullName: string;
    public location: string;
    public descriptionDetail: string;
    public imagePath: string

    constructor (id: number, fullName: string, location: string, descriptionDetail: string, imagePath: string)
    {
        this.id = id;
        this.fullName = fullName;
        this.location = location;
        this.descriptionDetail = descriptionDetail;
        this.imagePath = imagePath;
    }
}