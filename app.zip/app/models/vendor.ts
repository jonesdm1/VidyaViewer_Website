export class Vendor
{
    public id: number;
    public vendorName: string;
    public location: string;
    public detailDescription: string;
    public imagePath: string;

    constructor (id: number, vendorName: string, location: string, detailDescription: string, imagePath: string)
    {
        this.id = id;
        this.vendorName = vendorName;
        this.location = location;
        this.detailDescription = detailDescription;
        this.imagePath = imagePath;
    }
}