export class Rating
{
    public id: number;
    public esrb: string;
    public imagePath: string;

    constructor (id: number, esrb: string, imagePath: string)
    {
        this.id = id;
        this.esrb = esrb;
        this.imagePath = imagePath;
    }
}