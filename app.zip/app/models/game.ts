export class Game
{
    public id: number;
    public title: string;
    public ratingId: number;
    public descriptionDetail: string;
    public releaseDate: Date;
    public imagePath: string;
    
    constructor (id: number, title: string, ratingId: number, descriptionDetail: string, releaseDate: Date, imagePath: string)
    {
        this.id = id;
        this.title = title;
        this.ratingId = ratingId;
        this.descriptionDetail = descriptionDetail;
        this.releaseDate = releaseDate;
        this.imagePath = imagePath;
    }
}