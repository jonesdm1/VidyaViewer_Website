export class MultiPayload<T>
{
    public items: T[];
    public statusCode: number;
    public message: string;

    constructor(items: T[], statusCode: number, message: string)
    {
        this.items = items;
        this.statusCode = statusCode;
        this.message = message;
    }
}