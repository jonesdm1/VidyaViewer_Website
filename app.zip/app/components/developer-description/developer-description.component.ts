import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Subscription } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { ApiService } from '../../services/api.service';
import { SinglePayload } from '../../models/single-payload';
import { Developer } from '../../models/developer';

@Component({
  selector: 'app-developer-description',
  templateUrl: './developer-description.component.html',
  styleUrls: ['./developer-description.component.css']
})
export class DeveloperDescriptionComponent implements OnInit {

  public developer: Developer;

  private routeSubcription: Subscription;  
  constructor(private apiService: ApiService, private route: ActivatedRoute) { }

  public developerId: number;

  ngOnInit(): void 
  {
    this.routeSubcription = this.route.params.subscribe(params => {
      this.developerId = params['id'].substring(1);
      this.getDeveloperDetails(this.developerId);
    });
  }

  getDeveloperDetails(id: number)
  {
    this.apiService.getDeveloperDetails(id).subscribe(payload => {
      this.gotDeveloperDetails(payload)
      console.log(this.developer);
    });
  }

  gotDeveloperDetails(payload: SinglePayload<Developer>)
  {
    if (payload.item)
    {
      console.log(payload.item);
      
      this.developer = payload.item as Developer;
    }
  }
}
