import { Component, OnInit } from '@angular/core';
import { Developer } from '../../models/developer';
import { ApiService } from '../../services/api.service';
import { MultiPayload } from '../../models/multi-payload';
import { Router } from '@angular/router';

@Component({
  selector: 'app-developer-list',
  templateUrl: './developer-list.component.html',
  styleUrls: ['./developer-list.component.css']
})
export class DeveloperListComponent implements OnInit {

  public developers: Developer[] = [];

  constructor(private apiService: ApiService, private router: Router) { }

  ngOnInit(): void 
  {
    this.getListItems();
  }

  getListItems()
  {
    this.apiService.getDeveloperListItems().subscribe(payload => this.gotListItems(payload));
  }

  routeToDeveloperDescription(developerId: number)
  {
    this.router.navigate([`developer-description/:${developerId}`]);
  }

  gotListItems(payload: MultiPayload<Developer>)
  {
    if (payload.items)
    {
      console.log(payload.items);
      
      this.developers = payload.items as Developer[];
    }
  }
}
