import { Component, OnInit } from '@angular/core';
import { Vendor } from '../../models/vendor';
import { ApiService } from '../../services/api.service';
import { MultiPayload } from '../../models/multi-payload';
import { Router } from '@angular/router';

@Component({
  selector: 'app-vendor-list',
  templateUrl: './vendor-list.component.html',
  styleUrls: ['./vendor-list.component.css']
})
export class VendorListComponent implements OnInit {

  public vendors: Vendor[] = [];

  constructor(private apiService: ApiService, private router: Router) { }

  ngOnInit(): void
  {
    this.getListItems();
  }

  getListItems()
  {
    this.apiService.getVendorListItems().subscribe(payload => this.gotListItems(payload));
  }

  routeToVendorDescription(vendorId: number)
  {
    this.router.navigate([`vendor-description/:${vendorId}`]);
  }

  gotListItems(payload: MultiPayload<Vendor>)
  {
    if (payload.items)
    {
      console.log(payload.items);

      this.vendors = payload.items as Vendor[];
    }
  }
}
