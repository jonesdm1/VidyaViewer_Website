import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Game } from '../../models/game';

@Component({
  selector: 'app-game',
  templateUrl: './game.component.html',
  styleUrls: ['./game.component.css']
})
export class GameComponent implements OnInit 
{
  @Input()
  public game: Game;

  @Output()
  public onRouteToGameDescription: EventEmitter<number> = new EventEmitter();

  constructor() { }

  ngOnInit(): void {
  }

  routeToGameDescription()
  {
    this.onRouteToGameDescription.emit(this.game.id);
  }
}
