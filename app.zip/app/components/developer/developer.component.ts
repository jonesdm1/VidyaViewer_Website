import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Developer } from '../../models/developer';

@Component({
  selector: 'app-developer',
  templateUrl: './developer.component.html',
  styleUrls: ['./developer.component.css']
})
export class DeveloperComponent implements OnInit {

  @Input()
  public developer: Developer;

  @Output()
  public onRouteToDeveloperDescription: EventEmitter<number> = new EventEmitter();

  constructor() { }

  ngOnInit(): void {
  }

  routeToDeveloperDescription()
  {
    this.onRouteToDeveloperDescription.emit(this.developer.id);
  }

}
