import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Subscription } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { ApiService } from '../../services/api.service';
import { Vendor } from "../../models/vendor";
import { SinglePayload } from '../../models/single-payload';

@Component({
  selector: 'app-vendor-description',
  templateUrl: './vendor-description.component.html',
  styleUrls: ['./vendor-description.component.css']
})
export class VendorDescriptionComponent implements OnInit {

  public vendor: Vendor;

  private routeSubcription: Subscription;
  constructor(private apiService: ApiService, private route: ActivatedRoute) { }

  public vendorId: number;

  ngOnInit(): void
  {
    this.routeSubcription = this.route.params.subscribe(params => {
      this.vendorId = params['id'].substring(1);
      this.getVendorDetails(this.vendorId);
    });
  }

  getVendorDetails(id: number)
  {
    this.apiService.getVendorDetails(id).subscribe(payload => {
      this.gotVendorDetails(payload)
      console.log(this.vendor);
    });
  }

  gotVendorDetails(payload: SinglePayload<Vendor>)
  {
    if (payload.item)
    {
      console.log(payload.item);

      this.vendor = payload.item as Vendor;
    }
  }
}
