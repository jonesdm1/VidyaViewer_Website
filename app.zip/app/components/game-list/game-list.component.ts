import { Component, OnInit } from '@angular/core';
import { Game } from '../../models/game';
import { ApiService } from '../../services/api.service';
import { MultiPayload } from '../../models/multi-payload';
import { Router } from '@angular/router';

@Component({
  selector: 'app-game-list',
  templateUrl: './game-list.component.html',
  styleUrls: ['./game-list.component.css']
})
export class GameListComponent implements OnInit {

  public games: Game[] = [];

  constructor(private apiService: ApiService, private router: Router) { }

  ngOnInit(): void 
  {
    this.getListItems();
  }

  getListItems()
  {
    this.apiService.getGameListItems().subscribe(payload => this.gotListItems(payload));
  }

  routeToGameDescription(gameId: number)
  {
    this.router.navigate([`game-description/:${gameId}`]);
  }

  gotListItems(payload: MultiPayload<Game>)
  {
    if (payload.items)
    {
      console.log(payload.items);
      
      this.games = payload.items as Game[];
    }
  }
}
