import { Component, OnInit, ViewChild } from '@angular/core';
import { Game } from '../../../models/game';
import { AdminGameDialogComponent } from '../admin-game-dialog/admin-game-dialog.component';
import { ApiService } from '../../../services/api.service';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { MatDialogRef, MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { MultiPayload } from '../../../models/multi-payload';
import { GamePackage } from '../../../models/game-package';

@Component({
  selector: 'app-admin-game-page',
  templateUrl: './admin-game-page.component.html',
  styleUrls: ['./admin-game-page.component.css']
})
export class AdminGamePageComponent implements OnInit {

  @ViewChild(MatTable) gameTable: MatTable<Game>;

  public matDialogRef: MatDialogRef<AdminGameDialogComponent>;

  public games: Game[] = [];

  displayedColumns: string[] = ['title', 'ratingId', 'releaseDate', 'descriptionDetail', 'editAction'];
  dataSource: Game[] = null;

  constructor(public dialog: MatDialog, public apiService: ApiService) { }

  ngOnInit(): void 
  {
    this.getData();
  }

  getData()
  {
    this.apiService.getGameListItems().subscribe(
      s => this.gotGameList(s),
      e => console.log(e));
  }

  gotGameList(payload: MultiPayload<Game>)
  {
    if (payload != null)
    {
      this.games = payload.items as Game[];
      console.log(this.games);
    } 
    else
    {
      this.games = [];
    }
    this.dataSource = this.games;

    // this.handleLoading(false);
  }

  onCreateButtonPressed()
  {
    this.openDetailDialog(new GamePackage(new Game(0, null, 0, null, null, null), [], [], [], null));
    this.matDialogRef.componentInstance.action = 'Create';
    this.matDialogRef.componentInstance.onSubmit.subscribe((item: GamePackage) => 
    { 
       this.insertGame(item)
    });
  }

  onEditButtonPressed(gameId: number)
  {
    this.getGameDetailsById(gameId)
  }

  getGameDetailsById(gameId)
  {
    this.apiService.getGameDetails(gameId).subscribe(p => 
    {
      if (p.item)
      {
        let gamePackage = p.item as GamePackage;
        this.openDetailDialog(gamePackage);
        this.matDialogRef.componentInstance.action = 'Edit';
        this.matDialogRef.componentInstance.onSubmit.subscribe((item: GamePackage) => this.updateGame(item.game));
      }
    });
  }
  openDetailDialog(gamePackage: GamePackage)
  {
    let dialogConfig = new MatDialogConfig();
    dialogConfig.data = gamePackage;
    dialogConfig.width = '69%';
    dialogConfig.height = '83%';
    dialogConfig.panelClass = 'custom-dialog-container';
    dialogConfig.disableClose = true;

    this.matDialogRef = this.dialog.open(AdminGameDialogComponent, dialogConfig) as MatDialogRef<AdminGameDialogComponent>;
  }
  openEditDialog(data: Game)
  {
    const dialogRef = this.dialog.open(AdminGameDialogComponent, {
      width: '250px',
      data: data
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log(result);
      this.games = result;
    });
  }
  insertGame(data: GamePackage)
  {
    // this.handleLoading(true);
   
      this.apiService.createGame(data).subscribe({
        next: p => this.gameInserted(p),
        error: e => console.log(e)
      })
  }
  gameInserted(payload: any)
  {
    if (payload)
    {
      let game = payload.item as Game;

      if (game)
      {
        this.games.push(game);
        this.dataSource.push(game);
      }
    }
    // this.handleLoading(false);
  }
  updateGame(game: Game)
  {
    // this.handleLoading(true);
   
      this.apiService.updateGame(game).subscribe({
        next: p => this.gameUpdated(p),
        error: e => console.log(e)
      })
  }
  gameUpdated(payload: any)
  {
    if (payload)
    {
      let game = payload.item as Game;
      
      let i = this.games.findIndex(x => x.id === game.id);

      this.games[ i ] = game;
      this.dataSource[ i ] = game;
      console.log(this.games);
      this.gameTable.renderRows();
    }
  }
}
