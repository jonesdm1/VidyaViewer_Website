import { Component, OnInit, ViewChild } from '@angular/core';
import { Developer } from '../../../models/developer';
import { AdminDeveloperDialogComponent } from '../admin-developer-dialog/admin-developer-dialog.component';
import { ApiService } from '../../../services/api.service';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { MatDialogRef, MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { MultiPayload } from '../../../models/multi-payload';

@Component({
  selector: 'app-admin-developer-page',
  templateUrl: './admin-developer-page.component.html',
  styleUrls: ['./admin-developer-page.component.css']
})
export class AdminDeveloperPageComponent implements OnInit {
  @ViewChild(MatTable) developerTable: MatTable<Developer>;

  public matDialogRef: MatDialogRef<AdminDeveloperDialogComponent>;

  public developers: Developer[] = [];

  displayedColumns: string[] = ['fullName', 'location', 'descriptionDetail', 'editAction'];
  dataSource: Developer[] = null;

  constructor(public dialog: MatDialog, public apiService: ApiService) { }

  ngOnInit(): void 
  {
    this.getData();
  }

  getData()
  {
    this.apiService.getDeveloperListItems().subscribe(
      s => this.gotDeveloperList(s),
      e => console.log(e));
  }

  gotDeveloperList(payload: MultiPayload<Developer>)
  {
    if (payload != null)
    {
      this.developers = payload.items as Developer[];
      console.log(this.developers);
    } 
    else
    {
      this.developers = [];
    }
    this.dataSource = this.developers;

    // this.handleLoading(false);
  }

  onCreateButtonPressed()
  {
    this.openDetailDialog(new Developer(0, null, null, null, null));
    this.matDialogRef.componentInstance.action = 'Create';
    this.matDialogRef.componentInstance.onSubmit.subscribe((item: Developer) => 
    { 
       this.insertDeveloper(item)
    });
  }

  onEditButtonPressed(developerId: number)
  {
    this.getDeveloperDetailsById(developerId)
  }

  getDeveloperDetailsById(developerId)
  {
    this.apiService.getDeveloperDetails(developerId).subscribe(p => 
    {
      if (p.item)
      {
        let developer = p.item as Developer;
        this.openDetailDialog(developer);
        this.matDialogRef.componentInstance.action = 'Edit';
        this.matDialogRef.componentInstance.onSubmit.subscribe((item: Developer) => this.updateDeveloper(item));
      }
    });
  }
  openDetailDialog(developer: Developer)
  {
    let dialogConfig = new MatDialogConfig();
    dialogConfig.data = developer;
    dialogConfig.width = '69%';
    dialogConfig.height = '83%';
    dialogConfig.panelClass = 'custom-dialog-container';
    dialogConfig.disableClose = true;

    this.matDialogRef = this.dialog.open(AdminDeveloperDialogComponent, dialogConfig) as MatDialogRef<AdminDeveloperDialogComponent>;
  }
  openEditDialog(data: Developer)
  {
    const dialogRef = this.dialog.open(AdminDeveloperDialogComponent, {
      width: '250px',
      data: data
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log(result);
      this.developers = result;
    });
  }
  insertDeveloper(data: Developer)
  {
    // this.handleLoading(true);
   
      this.apiService.createDeveloper(data).subscribe({
        next: p => this.developerInserted(p),
        error: e => console.log(e)
      })
  }
  developerInserted(payload: any)
  {
    if (payload)
    {
      let developer = payload.item as Developer;

      if (developer)
      {
        this.developers.push(developer);
        this.dataSource.push(developer);
      }
    }
    // this.handleLoading(false);
  }
  updateDeveloper(developer: Developer)
  {
    // this.handleLoading(true);
   
      this.apiService.updateDeveloper(developer).subscribe({
        next: p => this.developerUpdated(p),
        error: e => console.log(e)
      })
  }
  developerUpdated(payload: any)
  {
    if (payload)
    {
      let developer = payload.item as Developer;
      
      let i = this.developers.findIndex(x => x.id === developer.id);

      this.developers[ i ] = developer;
      this.dataSource[ i ] = developer;
      console.log(this.developers);
      this.developerTable.renderRows();
    }
  }
}
