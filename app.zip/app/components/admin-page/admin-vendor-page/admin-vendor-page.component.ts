import { Component, OnInit, ViewChild } from '@angular/core';
import { Vendor } from '../../../models/vendor';
import { AdminVendorDialogComponent } from '../admin-vendor-dialog/admin-vendor-dialog.component';
import { ApiService } from '../../../services/api.service';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { MatDialogRef, MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { MultiPayload } from '../../../models/multi-payload';

@Component({
  selector: 'app-admin-vendor-page',
  templateUrl: './admin-vendor-page.component.html',
  styleUrls: ['./admin-vendor-page.component.css']
})
export class AdminVendorPageComponent implements OnInit{

  @ViewChild(MatTable) genreTable: MatTable<Vendor>;

  public matDialogRef: MatDialogRef<AdminVendorDialogComponent>;

  public vendors: Vendor[] = [];

  displayedColumns: string[] = ['vendorName', 'location', 'detailDescription', 'imagePath', 'editAction'];
  dataSource: Vendor[] = null;

  constructor(public dialog: MatDialog, public apiService: ApiService) { }

  ngOnInit(): void 
  {
    this.getData();
  }

  getData()
  {
    this.apiService.getVendorListItems().subscribe(
      s => this.gotVendorList(s),
      e => console.log(e));
  }

  gotVendorList(payload: MultiPayload<Vendor>)
  {
    if (payload != null)
    {
      this.vendors = payload.items as Vendor[];
      console.log(this.vendors);
    } 
    else
    {
      this.vendors = [];
    }
    this.dataSource = this.vendors;

    // this.handleLoading(false);
  }

  onCreateButtonPressed()
  {
    this.openDetailDialog(new Vendor(0, null, null, null, null));
    this.matDialogRef.componentInstance.action = 'Create';
    this.matDialogRef.componentInstance.onSubmit.subscribe((item: Vendor) => 
    { 
       this.insertVendor(item)
    });
  }

  onEditButtonPressed(vendorId: number)
  {
    this.getVendorDetailsById(vendorId)
  }

  getVendorDetailsById(vendorId)
  {
    this.apiService.getVendorDetails(vendorId).subscribe(p => 
    {
      if (p.item)
      {
        let vendor = p.item as Vendor;
        this.openDetailDialog(vendor);
        this.matDialogRef.componentInstance.action = 'Edit';
        this.matDialogRef.componentInstance.onSubmit.subscribe((item: Vendor) => this.updateVendor(item));
      }
    });
  }
  openDetailDialog(vendor: Vendor)
  {
    let dialogConfig = new MatDialogConfig();
    dialogConfig.data = vendor;
    dialogConfig.width = '69%';
    dialogConfig.height = '83%';
    dialogConfig.panelClass = 'custom-dialog-container';
    dialogConfig.disableClose = true;

    this.matDialogRef = this.dialog.open(AdminVendorDialogComponent, dialogConfig) as MatDialogRef<AdminVendorDialogComponent>;
  }
  openEditDialog(data: Vendor)
  {
    const dialogRef = this.dialog.open(AdminVendorDialogComponent, {
      width: '250px',
      data: data
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log(result);
      this.vendors = result;
    });
  }
  insertVendor(data: Vendor)
  {
    // this.handleLoading(true);
   
      this.apiService.createVendor(data).subscribe({
        next: p => this.vendorInserted(p),
        error: e => console.log(e)
      })
  }
  vendorInserted(payload: any)
  {
    if (payload)
    {
      let genre = payload.item as Vendor;

      if (genre)
      {
        this.vendors.push(genre);
        this.dataSource.push(genre);
      }
    }
    // this.handleLoading(false);
  }
  updateVendor(vendor: Vendor)
  {
    // this.handleLoading(true);
   
      this.apiService.updateVendor(vendor).subscribe({
        next: p => this.vendorUpdated(p),
        error: e => console.log(e)
      })
  }
  vendorUpdated(payload: any)
  {
    if (payload)
    {
      let genre = payload.item as Vendor;
      
      let i = this.vendors.findIndex(x => x.id === genre.id);

      this.vendors[ i ] = genre;
      this.dataSource[ i ] = genre;
      console.log(this.vendors);
      this.genreTable.renderRows();
    }
  }
}
