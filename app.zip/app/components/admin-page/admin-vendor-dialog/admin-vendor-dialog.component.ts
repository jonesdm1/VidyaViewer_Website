import { Component, Output, Inject, EventEmitter } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Vendor } from '../../../models/vendor';


@Component({
  selector: 'app-admin-vendor-dialog',
  templateUrl: './admin-vendor-dialog.component.html',
  styleUrls: ['./admin-vendor-dialog.component.css']
})
export class AdminVendorDialogComponent {

  public action: string;

  public item: Vendor;

  @Output()
  onSubmit: EventEmitter<any> = new EventEmitter();

  constructor(
    public dialogRef: MatDialogRef<AdminVendorDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: Vendor) 
    { 
      this.item = Object.assign({}, data);
    }

  onNoClick(): void {
    this.dialogRef.close();
  }

  submit()
  {
    console.log(this.item);
    this.onSubmit.emit(this.item);
    this.dialogRef.close();
  }
}
