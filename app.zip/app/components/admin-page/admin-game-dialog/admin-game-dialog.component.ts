import { Component, Output, Inject, EventEmitter } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { GamePackage } from '../../../models/game-package';


@Component({
  selector: 'app-admin-game-dialog',
  templateUrl: './admin-game-dialog.component.html',
  styleUrls: ['./admin-game-dialog.component.css']
})
export class AdminGameDialogComponent {

  public action: string;

  public item: GamePackage;

  @Output()
  onSubmit: EventEmitter<GamePackage> = new EventEmitter();

  constructor(
    public dialogRef: MatDialogRef<AdminGameDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: GamePackage) 
    { 
      this.item = Object.assign({}, data);
    }

  onNoClick(): void {
    this.dialogRef.close();
  }

  submit()
  {
    this.onSubmit.emit(this.item);
    this.dialogRef.close();
  }
}
