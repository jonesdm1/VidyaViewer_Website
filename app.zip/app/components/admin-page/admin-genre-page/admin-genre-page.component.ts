import { Component, OnInit, ViewChild } from '@angular/core';
import { Genre } from '../../../models/genre';
import { AdminGenreDialogComponent } from '../admin-genre-dialog/admin-genre-dialog.component';
import { ApiService } from '../../../services/api.service';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { MatDialogRef, MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { MultiPayload } from '../../../models/multi-payload';

@Component({
  selector: 'app-admin-genre-page',
  templateUrl: './admin-genre-page.component.html',
  styleUrls: ['./admin-genre-page.component.css']
})
export class AdminGenrePageComponent implements OnInit {

  @ViewChild(MatTable) genreTable: MatTable<Genre>;

  public matDialogRef: MatDialogRef<AdminGenreDialogComponent>;

  public genres: Genre[] = [];

  displayedColumns: string[] = ['genreName', 'descriptionDetail', 'editAction'];
  dataSource: Genre[] = null;

  constructor(public dialog: MatDialog, public apiService: ApiService) { }

  ngOnInit(): void 
  {
    this.getData();
  }

  getData()
  {
    this.apiService.getGenreListItems().subscribe(
      s => this.gotGenreList(s),
      e => console.log(e));
  }

  gotGenreList(payload: MultiPayload<Genre>)
  {
    if (payload != null)
    {
      this.genres = payload.items as Genre[];
      console.log(this.genres);
    } 
    else
    {
      this.genres = [];
    }
    this.dataSource = this.genres;

    // this.handleLoading(false);
  }

  onCreateButtonPressed()
  {
    this.openDetailDialog(new Genre(0, null, null));
    this.matDialogRef.componentInstance.action = 'Create';
    this.matDialogRef.componentInstance.onSubmit.subscribe((item: Genre) => 
    { 
       this.insertGenre(item)
    });
  }

  onEditButtonPressed(genreId: number)
  {
    this.getGameDetailsById(genreId)
  }

  getGameDetailsById(genreId)
  {
    this.apiService.getGenreDetails(genreId).subscribe(p => 
    {
      if (p.item)
      {
        let genre = p.item as Genre;
        this.openDetailDialog(genre);
        this.matDialogRef.componentInstance.action = 'Edit';
        this.matDialogRef.componentInstance.onSubmit.subscribe((item: Genre) => this.updateGenre(item));
      }
    });
  }
  openDetailDialog(genre: Genre)
  {
    let dialogConfig = new MatDialogConfig();
    dialogConfig.data = genre;
    dialogConfig.width = '69%';
    dialogConfig.height = '83%';
    dialogConfig.panelClass = 'custom-dialog-container';
    dialogConfig.disableClose = true;

    this.matDialogRef = this.dialog.open(AdminGenreDialogComponent, dialogConfig) as MatDialogRef<AdminGenreDialogComponent>;
  }
  openEditDialog(data: Genre)
  {
    const dialogRef = this.dialog.open(AdminGenreDialogComponent, {
      width: '250px',
      data: data
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log(result);
      this.genres = result;
    });
  }
  insertGenre(data: Genre)
  {
    // this.handleLoading(true);
   
      this.apiService.createGenre(data).subscribe({
        next: p => this.genreInserted(p),
        error: e => console.log(e)
      })
  }
  genreInserted(payload: any)
  {
    if (payload)
    {
      let genre = payload.item as Genre;

      if (genre)
      {
        this.genres.push(genre);
        this.dataSource.push(genre);
      }
    }
    // this.handleLoading(false);
  }
  updateGenre(genre: Genre)
  {
    // this.handleLoading(true);
   
      this.apiService.updateGenre(genre).subscribe({
        next: p => this.genreUpdated(p),
        error: e => console.log(e)
      })
  }
  genreUpdated(payload: any)
  {
    if (payload)
    {
      let genre = payload.item as Genre;
      
      let i = this.genres.findIndex(x => x.id === genre.id);

      this.genres[ i ] = genre;
      this.dataSource[ i ] = genre;
      console.log(this.genres);
      this.genreTable.renderRows();
    }
  }

}
