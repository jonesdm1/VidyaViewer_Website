import { Component, OnInit, ViewChild } from '@angular/core';
import { Rating } from '../../../models/rating';
import { AdminRatingDialogComponent } from '../admin-rating-dialog/admin-rating-dialog.component';
import { ApiService } from '../../../services/api.service';
import { MatTableDataSource, MatTable } from '@angular/material/table';
import { MatDialogRef, MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { MultiPayload } from '../../../models/multi-payload';

@Component({
  selector: 'app-admin-rating-page',
  templateUrl: './admin-rating-page.component.html',
  styleUrls: ['./admin-rating-page.component.css']
})
export class AdminRatingPageComponent implements OnInit {

  @ViewChild(MatTable) ratingTable: MatTable<Rating>;

  public matDialogRef: MatDialogRef<AdminRatingDialogComponent>;

  public ratings: Rating[] = [];

  displayedColumns: string[] = ['esrb', 'imagePath', 'editAction'];
  dataSource: Rating[] = null;

  constructor(public dialog: MatDialog, public apiService: ApiService) { }

  ngOnInit(): void 
  {
    this.getData();
  }

  getData()
  {
    this.apiService.getRatingListItems().subscribe(
      s => this.gotRatingList(s),
      e => console.log(e));
  }

  gotRatingList(payload: MultiPayload<Rating>)
  {
    if (payload != null)
    {
      this.ratings = payload.items as Rating[];
      console.log(this.ratings);
    } 
    else
    {
      this.ratings = [];
    }
    this.dataSource = this.ratings;

    // this.handleLoading(false);
  }

  onCreateButtonPressed()
  {
    this.openDetailDialog(new Rating(0, null, null));
    this.matDialogRef.componentInstance.action = 'Create';
    this.matDialogRef.componentInstance.onSubmit.subscribe((item: Rating) => 
    { 
       this.insertGenre(item)
    });
  }

  onEditButtonPressed(ratingId: number)
  {
    this.getRatingDetailsById(ratingId)
  }

  getRatingDetailsById(ratingId)
  {
    this.apiService.getRatingDetails(ratingId).subscribe(p => 
    {
      if (p.item)
      {
        let rating = p.item as Rating;
        this.openDetailDialog(rating);
        this.matDialogRef.componentInstance.action = 'Edit';
        this.matDialogRef.componentInstance.onSubmit.subscribe((item: Rating) => this.updateRating(item));
      }
    });
  }
  openDetailDialog(rating: Rating)
  {
    let dialogConfig = new MatDialogConfig();
    dialogConfig.data = rating;
    dialogConfig.width = '69%';
    dialogConfig.height = '83%';
    dialogConfig.panelClass = 'custom-dialog-container';
    dialogConfig.disableClose = true;

    this.matDialogRef = this.dialog.open(AdminRatingDialogComponent, dialogConfig) as MatDialogRef<AdminRatingDialogComponent>;
  }
  openEditDialog(data: Rating)
  {
    const dialogRef = this.dialog.open(AdminRatingDialogComponent, {
      width: '250px',
      data: data
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log(result);
      this.ratings = result;
    });
  }
  insertGenre(data: Rating)
  {
    // this.handleLoading(true);
   
      this.apiService.createRating(data).subscribe({
        next: p => this.ratingInserted(p),
        error: e => console.log(e)
      })
  }
  ratingInserted(payload: any)
  {
    if (payload)
    {
      let rating = payload.item as Rating;

      if (rating)
      {
        this.ratings.push(rating);
        this.dataSource.push(rating);
      }
    }
    // this.handleLoading(false);
  }
  updateRating(rating: Rating)
  {
    // this.handleLoading(true);
   
      this.apiService.updateRating(rating).subscribe({
        next: p => this.ratingUpdated(p),
        error: e => console.log(e)
      })
  }
  ratingUpdated(payload: any)
  {
    if (payload)
    {
      let rating = payload.item as Rating;
      
      let i = this.ratings.findIndex(x => x.id === rating.id);

      this.ratings[ i ] = rating;
      this.dataSource[ i ] = rating;
      console.log(this.ratings);
      this.ratingTable.renderRows();
    }
  }
}
