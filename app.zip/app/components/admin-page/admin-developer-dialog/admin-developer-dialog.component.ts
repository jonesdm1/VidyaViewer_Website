import { Component, EventEmitter, Output, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Developer } from '../../../models/developer';

@Component({
  selector: 'app-admin-developer-dialog',
  templateUrl: './admin-developer-dialog.component.html',
  styleUrls: ['./admin-developer-dialog.component.css']
})
export class AdminDeveloperDialogComponent {

  public action: string;

  public item: Developer;

  @Output()
  onSubmit: EventEmitter<Developer> = new EventEmitter();

  constructor(
    public dialogRef: MatDialogRef<AdminDeveloperDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: Developer) 
    { 
      this.item = Object.assign({}, data);
    }

  onNoClick(): void {
    this.dialogRef.close();
  }

  submit()
  {
    this.onSubmit.emit(this.item);
    this.dialogRef.close();
  }
}
