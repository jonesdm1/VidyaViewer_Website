import { Component, Output, Inject, EventEmitter } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Rating } from '../../../models/rating';

@Component({
  selector: 'app-admin-rating-dialog',
  templateUrl: './admin-rating-dialog.component.html',
  styleUrls: ['./admin-rating-dialog.component.css']
})
export class AdminRatingDialogComponent {

  public action: string;

  public item: Rating;

  @Output()
  onSubmit: EventEmitter<any> = new EventEmitter();

  constructor(
    public dialogRef: MatDialogRef<AdminRatingDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: Rating) 
    { 
      this.item = Object.assign({}, data);
    }

  onNoClick(): void {
    this.dialogRef.close();
  }

  submit()
  {
    
  }
}
