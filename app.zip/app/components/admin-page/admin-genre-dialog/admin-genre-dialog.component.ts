import { Component, Output, Inject, EventEmitter } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Genre } from '../../../models/genre';


@Component({
  selector: 'app-admin-genre-dialog',
  templateUrl: './admin-genre-dialog.component.html',
  styleUrls: ['./admin-genre-dialog.component.css']
})
export class AdminGenreDialogComponent {

  public action: string;

  public item: Genre;

  @Output()
  onSubmit: EventEmitter<any> = new EventEmitter();

  constructor(
    public dialogRef: MatDialogRef<AdminGenreDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: Genre) 
    { 
      this.item = Object.assign({}, data);
    }

  onNoClick(): void {
    this.dialogRef.close();
  }

  submit()
  {
    console.log(this.item);
    this.onSubmit.emit(this.item);
    this.dialogRef.close();
  }
}
