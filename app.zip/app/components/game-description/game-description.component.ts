import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Subscription } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { ApiService } from '../../services/api.service';
import { GamePackage } from "../../models/game-package";
import { SinglePayload } from '../../models/single-payload';

@Component({
  selector: 'app-game-description',
  templateUrl: './game-description.component.html',
  styleUrls: ['./game-description.component.css']
})
export class GameDescriptionComponent implements OnInit {

  public gamePackage: GamePackage;

  private routeSubcription: Subscription;  
  constructor(private apiService: ApiService, private route: ActivatedRoute) { }

  public gameId: number;

  ngOnInit(): void 
  {
    this.routeSubcription = this.route.params.subscribe(params => {
      this.gameId = params['id'].substring(1);
      this.getGameDetails(this.gameId);
    });
  }

  getGameDetails(id: number)
  {
    this.apiService.getGameDetails(id).subscribe(payload => {
      this.gotGameDetails(payload)
      console.log(this.gamePackage.game);
    });
  }

  gotGameDetails(payload: SinglePayload<GamePackage>)
  {
    if (payload.item)
    {
      console.log(payload.item);
      
      this.gamePackage = payload.item as GamePackage;
    }
  }
}
