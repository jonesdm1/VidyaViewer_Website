import { InjectionToken, NgModule, APP_INITIALIZER } from '@angular/core';

import { ConfigService } from './services/config.service';

const AUTH_CONFIG_URL_TOKEN = new InjectionToken<string>('AUTH_CONFIG_URL');

export function initializerFactory(config: ConfigService, configUrl: string): any
{
    const promise = config.init(configUrl).then((value) =>
    {
    });
    return () => promise;
}

@NgModule({
    providers: [],
    imports: []
})
export class ConfigAppModule
{
    static forRoot(configFile: string)
    {
        return {
            ngModule: ConfigAppModule,
            providers: [
                ConfigService,
                { provide: AUTH_CONFIG_URL_TOKEN, useValue: configFile },
                {
                    provide: APP_INITIALIZER, useFactory: initializerFactory,
                    deps: [ ConfigService, AUTH_CONFIG_URL_TOKEN ], multi: true
                }
            ]
        };
    }
}