import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BaseService } from './base.service';
import { Observable } from 'rxjs';
import { SinglePayload } from '../models/single-payload';
import { ConfigService } from './config.service';
import { MultiPayload } from '../models/multi-payload';
import { Game } from '../models/game';
import { Developer } from '../models/developer';
import { Genre } from '../models/genre';
import { Rating } from '../models/rating';
import { Vendor } from '../models/vendor';
import { GamePackage } from "../models/game-package";

@Injectable()
export class ApiService extends BaseService
{
    constructor(config: ConfigService, httpClient: HttpClient)
    {
        super(config, httpClient);
    }

    // CRUD Methods for GAME
    public createGame(gamePackage: GamePackage): Observable<SinglePayload<Game>>
    {
        console.log('WE ARE HERE!');
        
        console.log(gamePackage);
        let url = `${this._baseUrl}/game`;

        console.log(url);

        return this.postData(url, gamePackage.game);
    }
    public getGameListItems(): Observable<MultiPayload<Game>>
    {
        let url = `${this._baseUrl}/game/list`;
        
        return this.getData(url);
    }
    public getGameDetails(id: number): Observable<SinglePayload<GamePackage>>
    {
        let url = `${this._baseUrl}/game/details/${id}`;
        
        return this.getData(url);
    }
    public updateGame(game: Game): Observable<SinglePayload<Game>>
    {
        let url = `${this._baseUrl}/game`;

        return this.put(url, game);
    }

    // CRUD Methods for DEVELOPER
    public createDeveloper(developer: Developer): Observable<SinglePayload<Developer>>
    {
        console.log('WE ARE HERE!');
        
        console.log(developer);
        let url = `${this._baseUrl}/developer`;

        console.log(url);

        return this.postData(url, developer);
    }
    public getDeveloperListItems(): Observable<MultiPayload<Developer>>
    {
        let url = `${this._baseUrl}/developer/list`;
        
        return this.getData(url);
    }
    public getDeveloperDetails(id: number): Observable<SinglePayload<Developer>>
    {
        let url = `${this._baseUrl}/developer/details/${id}`;
        
        return this.getData(url);
    }
    public updateDeveloper(developer: Developer): Observable<SinglePayload<Developer>>
    {
        let url = `${this._baseUrl}/developer`;

        return this.put(url, developer);
    }
    
    // CRUD Methods for GENRES
    public createGenre(genre: Genre): Observable<SinglePayload<Genre>>
    {
        console.log('WE ARE HERE!');
        
        console.log(genre);
        let url = `${this._baseUrl}/genre`;

        console.log(url);

        return this.postData(url, genre);
    }
    public getGenreListItems(): Observable<MultiPayload<Genre>>
    {
        let url = `${this._baseUrl}/genre/list`;
        
        return this.getData(url);
    }
    public getGenreDetails(id: number): Observable<SinglePayload<Genre>>
    {
        let url = `${this._baseUrl}/genre/details/${id}`;
        
        return this.getData(url);
    }
    public updateGenre(genre: Genre): Observable<SinglePayload<Genre>>
    {
        let url = `${this._baseUrl}/genre`;
        console.log(genre);

        return this.put(url, genre);
    }
    // CRUD Methods for RATING
    public createRating(rating: Rating): Observable<SinglePayload<Rating>>
    {
        console.log('WE ARE HERE!');
        
        console.log(rating);
        let url = `${this._baseUrl}/rating`;

        console.log(url);

        return this.postData(url, rating);
    }
    public getRatingListItems(): Observable<MultiPayload<Rating>>
    {
        let url = `${this._baseUrl}/rating/list`;
        
        return this.getData(url);
    }
    public getRatingDetails(id: number): Observable<SinglePayload<Rating>>
    {
        let url = `${this._baseUrl}/rating/details/${id}`;
        
        return this.getData(url);
    }
    public updateRating(rating: Rating): Observable<SinglePayload<Rating>>
    {
        let url = `${this._baseUrl}/rating`;
        console.log(rating);

        return this.put(url, rating);
    }

    // CRUD Methods for VENDOR
    public createVendor(vendor: Vendor): Observable<SinglePayload<Vendor>>
    {
        console.log('WE ARE HERE!');
        
        console.log(vendor);
        let url = `${this._baseUrl}/vendor`;

        console.log(url);

        return this.postData(url, vendor);
    }
    public getVendorListItems(): Observable<MultiPayload<Vendor>>
    {
        let url = `${this._baseUrl}/vendor/list`;
        
        return this.getData(url);
    }
    public getVendorDetails(id: number): Observable<SinglePayload<Vendor>>
    {
        let url = `${this._baseUrl}/vendor/details/${id}`;
        
        return this.getData(url);
    }
    public updateVendor(vendor: Vendor): Observable<SinglePayload<Vendor>>
    {
        let url = `${this._baseUrl}/vendor`;
        console.log(vendor);

        return this.put(url, vendor);
    }
}