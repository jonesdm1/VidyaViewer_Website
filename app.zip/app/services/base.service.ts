import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ConfigService } from './config.service';

@Injectable({
    providedIn: 'root'
})
export class BaseService
{
    protected _baseUrl: string;
    protected _httpClient: HttpClient;
    protected _options: {
        headers: {
            'Content-Type': string
        }
    }

    constructor(protected config: ConfigService, protected httpClient: HttpClient)
    {
        this._options = {
            headers: {
                'Content-Type': 'application/json;charset=utf-8'
            }
        }
        this._httpClient = httpClient;
        this._baseUrl = config.getSettings('apiBaseUrl');
    }

    protected getData(url: string): Observable<any>
    {
        var obs: Observable<any> = new Observable();

        obs = this.httpClient.get(url, this._options);

        return obs;
    }

    protected post(url: string): Observable<any>
    {
        var obs: Observable<any> = new Observable();

        obs = this.httpClient.post(url, this._options);

        return obs;
    }

    protected postData(url: string, body: any): Observable<any>
    {
        var obs: Observable<any> = new Observable();

        obs = this.httpClient.post(url, body, this._options);

        return obs;
    }

    protected put(url: string, item: any): Observable<any>
    {
        return this.httpClient.put<any>(url, item, this._options)
    }
}