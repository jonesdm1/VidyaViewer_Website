﻿
namespace VidyaViewerAPI.Models.Payloads
{
    public class ErrorPayload
    {
        public string Message { get; set; }

        public int StatusCode { get; set; }
    }
}
