﻿using System;
using VidyaViewerAPI.Models.Settings;
using System.Data.SqlClient;
using VidyaViewerAPI.Models.Exceptions;

// Programmed by David Jones
// Third layer of API
// Purpose pass SQL statements to databse

namespace VidyaViewerAPI.Repositories
{
    public interface IGameDeveloperRepository
    {
        int Insert(int gameId, int developerId);

        int DeleteByDeveloper(int developerId);

        int DeleteByGame(int gameId);
    }

    public class GameDeveloperRepository : IGameDeveloperRepository
    {
        // SQL command to call to database
        private string _insertQuery =>
        @"
            INSERT INTO [dbo].[GameDeveloper]
            (
                [GameId],
                [DeveloperId]
            ) 
            VALUES 
            (
                @GameId,
                @DeveloperId
            );
            SELECT CAST(SCOPE_IDENTITY() AS INT);
        ";

        private string _deleteByDeveloperQuery =>
        @"
            DELETE FROM [dbo].[GameDeveloper]
            WHERE DeveloperId = @Id;
        ";

        private string _deleteByGameQuery =>
        @"
            DELETE FROM [dbo].[GameDeveloper]
            WHERE GameId = @Id;
        ";

        private readonly IVidyaViewerAdoSettings _adoSettings;

        public GameDeveloperRepository(IVidyaViewerAdoSettings adoSettings)
        {
            _adoSettings = adoSettings;
        }

        public int Insert(int gameId, int developerId)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_adoSettings.ConnectionString))
                {
                    SqlCommand command = new SqlCommand(_insertQuery, connection);

                    command.Parameters.Add(new SqlParameter("@DeveloperId", developerId));
                    command.Parameters.Add(new SqlParameter("@GameId", gameId));

                    connection.Open();
                    return (int)command.ExecuteScalar();
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new RepositoryException(e.Message);
            }
        }

        public int DeleteByDeveloper(int developerId)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_adoSettings.ConnectionString))
                {
                    SqlCommand command = new SqlCommand(_deleteByDeveloperQuery, connection);

                    command.Parameters.Add(new SqlParameter("@DeveloperId", developerId));

                    connection.Open();
                    return command.ExecuteNonQuery();
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new RepositoryException(e.Message);
            }
        }

        public int DeleteByGame(int gameId)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_adoSettings.ConnectionString))
                {
                    SqlCommand command = new SqlCommand(_deleteByGameQuery, connection);

                    command.Parameters.Add(new SqlParameter("@GameId", gameId));

                    connection.Open();
                    return command.ExecuteNonQuery();
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new RepositoryException(e.Message);
            }
        }
    }
}
