﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VidyaViewerAPI.Models;
using VidyaViewerAPI.Models.Settings;
using System.Data.SqlClient;
using VidyaViewerAPI.Models.Exceptions;
using System.Data;
using VidyaViewerAPI.Extensions.Repository;

// Programmed by David Jones
// Third layer of API
// Purpose pass SQL statements to databse

namespace VidyaViewerAPI.Repositories
{
    public class GameVendorRepository
    {
        private string _insertQuery =>
        @"
            INSERT INTO [dbo].[GameDeveloper]
            (
                [GameId],
                [DeveloperId]
            ) 
            VALUES 
            (
                @GameId,
                @DeveloperId
            );
            SELECT CAST(SCOPE_IDENTITY() AS INT);
        ";

        private string _deleteQuery =>
        @"
            DELETE FROM [dbo].[Developer]
            WHERE DeveloperId = @Id;
        ";

        private readonly IVidyaViewerAdoSettings _adoSettings;

        public GameVendorRepository(IVidyaViewerAdoSettings adoSettings)
        {
            _adoSettings = adoSettings;
        }
    }
}
