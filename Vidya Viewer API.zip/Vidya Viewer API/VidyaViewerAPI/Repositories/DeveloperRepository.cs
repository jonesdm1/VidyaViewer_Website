﻿using System;
using System.Collections.Generic;
using VidyaViewerAPI.Models;
using VidyaViewerAPI.Models.Settings;
using System.Data.SqlClient;
using VidyaViewerAPI.Models.Exceptions;
using System.Data;
using VidyaViewerAPI.Extensions.Repository;

// Programmed by David Jones
// Third layer of API
// Purpose pass SQL statements to databse

namespace VidyaViewerAPI.Repositories
{
    public interface IDeveloperRepository
    {
        int Insert(IDeveloper developer);

        IEnumerable<IDeveloper> GetListItems();

        IDeveloper GetById(int id);

        IEnumerable<IDeveloper> GetGameDetails(int id);

        int Update(IDeveloper developer);

        int Delete(int id);
    }

    public class DeveloperRepository : IDeveloperRepository
    {
        // SQL command to call to database
        private string _insertQuery => @"
            INSERT INTO [dbo].[Developer]
            (
                [FullName], 
                [Location],
                [DescriptionDetail],
                [ImagePath]
            ) 
            VALUES 
            (
                @FullName, 
                @Location,
                @DescriptionDetail,
                @ImagePath
            );
            SELECT CAST(SCOPE_IDENTITY() AS INT);";

        private string _getListItemsQuery =>
        @"
            SELECT
                DeveloperId AS Id,
                FullName,
                Location,
                DescriptionDetail,
                ImagePath
            FROM Developer;
        ";

        private string _getByIdQuery =>
        @"
            SELECT
                DeveloperId AS Id,
                FullName,
                Location,
                DescriptionDetail,
                ImagePath
            FROM Developer
            WHERE DeveloperId = @Id;
        ";

        private string _getGameDetailsQuery =>
        @"
            SELECT
                Developer.DeveloperId AS Id,
                FullName,
                Location,
                DescriptionDetail,
                ImagePath
            FROM Developer
            LEFT OUTER JOIN GameDeveloper ON Developer.DeveloperId = GameDeveloper.DeveloperId
            WHERE GameId = @Id;
        ";

        private string _updateQuery =>
        @"
            UPDATE [dbo].[Developer]
            SET FullName = @FullName,
                Location = @Location,
                DescriptionDetail = @DescriptionDetail,
                ImagePath = @ImagePath
            WHERE DeveloperId = @Id;
        ";

        private string _deleteQuery =>
        @"
            DELETE FROM [dbo].[Developer]
            WHERE DeveloperId = @Id;
        ";

        private readonly IVidyaViewerAdoSettings _adoSettings;

        public DeveloperRepository(IVidyaViewerAdoSettings adoSettings)
        {
            _adoSettings = adoSettings;
        }

        public int Insert(IDeveloper developer)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_adoSettings.ConnectionString))
                {
                    SqlCommand command = new SqlCommand(_insertQuery, connection);

                    foreach (SqlParameter sqlParameter in GenerateInsertSqlParameters(developer))
                        command.Parameters.Add(sqlParameter);

                    connection.Open();
                    return (int)command.ExecuteScalar();
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new RepositoryException(e.Message);
            }
        }

        public IEnumerable<IDeveloper> GetListItems()
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection sqlConnection = new System.Data.SqlClient.SqlConnection(_adoSettings.ConnectionString))
                {
                    sqlConnection.Open();

                    using (SqlCommand command = new SqlCommand(_getListItemsQuery, sqlConnection))
                    using (IDataReader reader = command.ExecuteReader())
                    {
                        var listItems = new List<Developer>();

                        while (reader.Read())
                        {
                            var listItem = new Developer().PopulateDeveloper(reader);

                            listItems.Add(listItem);
                        }

                        return listItems;
                    }
                }
            }
            catch (Exception e)
            {
                throw (e);
            }
        }

        public IDeveloper GetById(int id)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection sqlConnection = new System.Data.SqlClient.SqlConnection(_adoSettings.ConnectionString))
                {
                    sqlConnection.Open();

                    using (SqlCommand command = new SqlCommand(_getByIdQuery, sqlConnection))
                    {
                        command.Parameters.Add(new SqlParameter("@Id", id));
                        using (IDataReader reader = command.ExecuteReader())
                        {
                            var developer = new Developer();

                            while (reader.Read())
                            {
                                developer = new Developer().PopulateDeveloper(reader);
                            }

                            return developer;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                throw (e);
            }
        }

        // Used for GamePackage
        public IEnumerable<IDeveloper> GetGameDetails(int id)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection sqlConnection = new System.Data.SqlClient.SqlConnection(_adoSettings.ConnectionString))
                {
                    sqlConnection.Open();

                    using (SqlCommand command = new SqlCommand(_getGameDetailsQuery, sqlConnection))
                    {
                        command.Parameters.Add(new SqlParameter("@Id", id));
                        using (IDataReader reader = command.ExecuteReader())
                        {
                            var developers = new List<Developer>();

                            while (reader.Read())
                            {
                                var developer = new Developer().PopulateDeveloper(reader);

                                developers.Add(developer);
                            }

                            return developers;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                throw (e);
            }
        }

        public int Update(IDeveloper developer)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_adoSettings.ConnectionString))
                {
                    SqlCommand command = new SqlCommand(_updateQuery, connection);

                    foreach (SqlParameter sqlParameter in GenerateUpdateSqlParameters(developer))
                        command.Parameters.Add(sqlParameter);

                    connection.Open();
                    return command.ExecuteNonQuery();
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new RepositoryException(e.Message);
            }
        }

        public int Delete(int id)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_adoSettings.ConnectionString))
                {
                    SqlCommand command = new SqlCommand(_deleteQuery, connection);

                    command.Parameters.Add(new SqlParameter("@Id", id));

                    connection.Open();
                    return command.ExecuteNonQuery();
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new RepositoryException(e.Message);
            }
        }

        // The purose of these two methods is to declare the neccessary variables
        // to use in SQL commands

        private SqlParameter[] GenerateInsertSqlParameters(IDeveloper developer)
        {
            var parameters = new[]
            {
                new SqlParameter("@FullName", developer.FullName),
                new SqlParameter("@Location", developer.Location),
                new SqlParameter("@DescriptionDetail", developer.DescriptionDetail),
                new SqlParameter("@ImagePath", developer.ImagePath)
            };
            return parameters;
        }

        private SqlParameter[] GenerateUpdateSqlParameters(IDeveloper developer)
        {
            var parameters = new[]
            {
                new SqlParameter("@Id", developer.Id),
                new SqlParameter("@FullName", developer.FullName),
                new SqlParameter("@Location", developer.Location),
                new SqlParameter("@DescriptionDetail", developer.DescriptionDetail),
                new SqlParameter("@ImagePath", developer.ImagePath)
            };
            return parameters;
        }
    }
}
