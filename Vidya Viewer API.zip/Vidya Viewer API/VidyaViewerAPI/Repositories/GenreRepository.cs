﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VidyaViewerAPI.Models;
using VidyaViewerAPI.Models.Settings;
using System.Data.SqlClient;
using VidyaViewerAPI.Models.Exceptions;
using System.Data;
using VidyaViewerAPI.Extensions.Repository;

// Programmed by David Jones
// Third layer of API
// Purpose pass SQL statements to databse

namespace VidyaViewerAPI.Repositories
{
    public interface IGenreRepository
    {
        // working on
        int Insert(IGenre genre);

        // not done
        IEnumerable<IGenre> GetListItems();

        // not done
        IGenre GetById(int id);

        // done
        IEnumerable<IGenre> GetGameDetails(int id);

        // working
        int Update(IGenre genre);

        // not done
        int Delete(int id);
    }

    public class GenreRepository : IGenreRepository
    {
        private string _insertQuery => @"
            INSERT INTO [dbo].[Genre]
            (
                [GenreName],
                [DescriptionDetail]
            ) 
            VALUES 
            (
                @GenreName,
                @DescriptionDetail
            );
            SELECT CAST(SCOPE_IDENTITY() AS INT);";

        private string _getListItemsQuery =>
        @"
            SELECT
                GenreId AS Id,
                GenreName,
                DescriptionDetail
            FROM Genre
        ";

        private string _getByIdQuery =>
        @"
            SELECT
                GenreId AS Id,
                GenreName,
                DescriptionDetail
            FROM Genre
            WHERE GenreId = @Id;
        ";

        private string _getGameDetailsQuery =>
        @"
            SELECT
                Genre.GenreId AS Id,
                GenreName,
                DescriptionDetail
            FROM Genre
            LEFT OUTER JOIN GameGenre ON Genre.GenreId = GameGenre.GenreId
            WHERE GameId = @Id;
        ";

        private string _updateQuery =>
        @"
            UPDATE [dbo].[Genre]
            SET GenreName = @GenreName,
                DescriptionDetail = @DescriptionDetail
            WHERE GenreId = @Id;
        ";

        private string _deleteQuery =>
        @"
            DELETE FROM [dbo].[Genre]
            WHERE GenreId = @Id;
        ";

        private readonly IVidyaViewerAdoSettings _adoSettings;

        public GenreRepository(IVidyaViewerAdoSettings adoSettings)
        {
            _adoSettings = adoSettings;
        }

        public int Insert(IGenre genre)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_adoSettings.ConnectionString))
                {
                    SqlCommand command = new SqlCommand(_insertQuery, connection);

                    foreach (SqlParameter sqlParameter in GenerateInsertSqlParameters(genre))
                        command.Parameters.Add(sqlParameter);

                    connection.Open();
                    return (int)command.ExecuteScalar();
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new RepositoryException(e.Message);
            }
        }

        public IEnumerable<IGenre> GetListItems()
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection sqlConnection = new System.Data.SqlClient.SqlConnection(_adoSettings.ConnectionString))
                {
                    sqlConnection.Open();

                    using (SqlCommand command = new SqlCommand(_getListItemsQuery, sqlConnection))
                    using (IDataReader reader = command.ExecuteReader())
                    {
                        var listItems = new List<Genre>();

                        while (reader.Read())
                        {
                            var listItem = new Genre().PopulateGenre(reader);

                            listItems.Add(listItem);
                        }

                        return listItems;
                    }
                }
            }
            catch (Exception e)
            {
                throw (e);
            }
        }

        public IGenre GetById(int id)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection sqlConnection = new System.Data.SqlClient.SqlConnection(_adoSettings.ConnectionString))
                {
                    sqlConnection.Open();

                    using (SqlCommand command = new SqlCommand(_getByIdQuery, sqlConnection))
                    {
                        command.Parameters.Add(new SqlParameter("@Id", id));
                        using (IDataReader reader = command.ExecuteReader())
                        {
                            var genre = new Genre();

                            while (reader.Read())
                            {
                                genre = new Genre().PopulateGenre(reader);
                            }

                            return genre;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                throw (e);
            }
        }

        // Used for GamePackage
        public IEnumerable<IGenre> GetGameDetails(int id)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection sqlConnection = new System.Data.SqlClient.SqlConnection(_adoSettings.ConnectionString))
                {
                    sqlConnection.Open();

                    using (SqlCommand command = new SqlCommand(_getGameDetailsQuery, sqlConnection))
                    {
                        command.Parameters.Add(new SqlParameter("@Id", id));
                        using (IDataReader reader = command.ExecuteReader())
                        {
                            var genres = new List<Genre>();

                            while (reader.Read())
                            {
                                var genre = new Genre().PopulateGenre(reader);

                                genres.Add(genre);
                            }

                            return genres;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                throw (e);
            }
        }

        public int Update(IGenre genre)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_adoSettings.ConnectionString))
                {
                    SqlCommand command = new SqlCommand(_updateQuery, connection);

                    foreach (SqlParameter sqlParameter in GenerateUpdateSqlParameters(genre))
                        command.Parameters.Add(sqlParameter);

                    connection.Open();
                    return command.ExecuteNonQuery();
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new RepositoryException(e.Message);
            }
        }

        public int Delete(int id)
        {
            throw new NotImplementedException();
        }

        // The purose of these two methods is to declare the neccessary variables
        // to use in SQL commands

        private SqlParameter[] GenerateInsertSqlParameters(IGenre genre)
        {
            var parameters = new[]
            {
                new SqlParameter("@GenreName", genre.GenreName),
                new SqlParameter("@DescriptionDetail", genre.DescriptionDetail)
            };
            return parameters;
        }

        private SqlParameter[] GenerateUpdateSqlParameters(IGenre genre)
        {
            var parameters = new[]
            {
                new SqlParameter("@Id", genre.Id),
                new SqlParameter("@GenreName", genre.GenreName),
                new SqlParameter("@DescriptionDetail", genre.DescriptionDetail)
            };
            return parameters;
        }
    }
}
