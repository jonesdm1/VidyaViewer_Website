﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VidyaViewerAPI.Models;
using VidyaViewerAPI.Models.Settings;
using System.Data.SqlClient;
using VidyaViewerAPI.Models.Exceptions;
using System.Data;
using VidyaViewerAPI.Extensions.Repository;

// Programmed by David Jones
// Third layer of API
// Purpose pass SQL statements to databse

namespace VidyaViewerAPI.Repositories
{
    public interface IGameGenreRepository
    {
        int Insert(int gameId, int genreId);

        int DeleteByGenre(int genreId);

        int DeleteByGame(int gameId);
    }

    public class GameGenreRepository : IGameGenreRepository
    {
        private string _insertQuery =>
        @"
            INSERT INTO [dbo].[GameGenre]
            (
                [GameId],
                [GenreId]
            ) 
            VALUES 
            (
                @GameId,
                @GenreId
            );
            SELECT CAST(SCOPE_IDENTITY() AS INT);
        ";

        private string _deleteByGenreQuery =>
        @"
            DELETE FROM [dbo].[GameGenre]
            WHERE GenreId = @Id;
        ";

        private string _deleteByGameQuery =>
        @"
            DELETE FROM [dbo].[GameDeveloper]
            WHERE GameId = @Id;
        ";

        private readonly IVidyaViewerAdoSettings _adoSettings;

        public GameGenreRepository(IVidyaViewerAdoSettings adoSettings)
        {
            _adoSettings = adoSettings;
        }

        public int Insert(int gameId, int genreId)
        {
            throw new NotImplementedException();
        }

        public int DeleteByGenre(int genreId)
        {
            throw new NotImplementedException();
        }

        public int DeleteByGame(int gameId)
        {
            throw new NotImplementedException();
        }
    }
}
