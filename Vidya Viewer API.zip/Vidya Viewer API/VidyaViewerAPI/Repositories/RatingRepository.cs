﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VidyaViewerAPI.Models;
using VidyaViewerAPI.Models.Settings;
using System.Data.SqlClient;
using VidyaViewerAPI.Models.Exceptions;
using System.Data;
using VidyaViewerAPI.Extensions.Repository;

// Programmed by David Jones
// Third layer of API
// Purpose pass SQL statements to databse

namespace VidyaViewerAPI.Repositories
{
    public interface IRatingRepository
    {
        // done
        int Insert(IRating rating);

        // done
        IEnumerable<IRating> GetListItems();

        // not done
        IRating GetById(int id);

        // done
        IRating GetByGameId(int id);

        // not done
        int Update(IRating rating);

        // not done
        int Delete(int id);
    }

    public class RatingRepository : IRatingRepository
    {
        private string _insertQuery => @"
            INSERT INTO [dbo].[Rating]
            (
                [Esrb],
                [ImagePath]
            ) 
            VALUES 
            (
                @Esrb,
                @ImagePath
            );
            SELECT CAST(SCOPE_IDENTITY() AS INT);";

        private string _getListItemsQuery =>
        @"
            SELECT
                RatingId AS Id,
                Esrb,
                ImagePath
            FROM Rating
        ";

        private string _getByIdQuery =>
        @"
            SELECT
                RatingId AS Id,
                Esrb,
                ImagePath
            FROM Rating
            WHERE RatingId = @Id;
        ";

        private string _getByGameIdQuery =>
        @"
            SELECT
                Rating.RatingId AS Id,
                Esrb,
                Rating.ImagePath
            FROM Rating
            LEFT OUTER JOIN Game ON Rating.RatingId = Game.RatingId
            WHERE GameId = @Id;
        ";

        private string _updateQuery =>
        @"
            UPDATE [dbo].[Rating]
            SET Esrb = @Esrb,
                ImagePath = @ImagePath
            WHERE RatingId = @Id;
        ";

        private string _deleteQuery =>
        @"
            DELETE FROM [dbo].[Rating]
            WHERE RatingId = @Id;
        ";

        private readonly IVidyaViewerAdoSettings _adoSettings;

        public RatingRepository(IVidyaViewerAdoSettings adoSettings)
        {
            _adoSettings = adoSettings;
        }

        public int Insert(IRating rating)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_adoSettings.ConnectionString))
                {
                    SqlCommand command = new SqlCommand(_insertQuery, connection);

                    foreach (SqlParameter sqlParameter in GenerateInsertSqlParameters(rating))
                        command.Parameters.Add(sqlParameter);

                    connection.Open();
                    return (int)command.ExecuteScalar();
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new RepositoryException(e.Message);
            }
        }

        public IEnumerable<IRating> GetListItems()
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection sqlConnection = new System.Data.SqlClient.SqlConnection(_adoSettings.ConnectionString))
                {
                    sqlConnection.Open();

                    using (SqlCommand command = new SqlCommand(_getListItemsQuery, sqlConnection))
                    using (IDataReader reader = command.ExecuteReader())
                    {
                        var listItems = new List<Rating>();

                        while (reader.Read())
                        {
                            var listItem = new Rating().PopulateRating(reader);

                            listItems.Add(listItem);
                        }

                        return listItems;
                    }
                }
            }
            catch (Exception e)
            {
                throw (e);
            }
        }

        public IRating GetById(int id)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection sqlConnection = new System.Data.SqlClient.SqlConnection(_adoSettings.ConnectionString))
                {
                    sqlConnection.Open();

                    using (SqlCommand command = new SqlCommand(_getByIdQuery, sqlConnection))
                    {
                        command.Parameters.Add(new SqlParameter("@Id", id));
                        using (IDataReader reader = command.ExecuteReader())
                        {
                            var rating = new Rating();

                            while (reader.Read())
                            {
                                rating = new Rating().PopulateRating(reader);
                            }

                            return rating;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                throw (e);
            }
        }

        public IRating GetByGameId(int id)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection sqlConnection = new System.Data.SqlClient.SqlConnection(_adoSettings.ConnectionString))
                {
                    sqlConnection.Open();

                    using (SqlCommand command = new SqlCommand(_getByGameIdQuery, sqlConnection))
                    {
                        command.Parameters.Add(new SqlParameter("@Id", id));
                        using (IDataReader reader = command.ExecuteReader())
                        {
                            var rating = new Rating();

                            if (reader.Read())
                            {
                                rating = new Rating().PopulateRating(reader);
                            }
                            return rating;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                throw (e);
            }
        }

        public int Update(IRating rating)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_adoSettings.ConnectionString))
                {
                    SqlCommand command = new SqlCommand(_updateQuery, connection);

                    foreach (SqlParameter sqlParameter in GenerateUpdateSqlParameters(rating))
                        command.Parameters.Add(sqlParameter);

                    connection.Open();
                    return command.ExecuteNonQuery();
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new RepositoryException(e.Message);
            }
        }

        public int Delete(int id)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_adoSettings.ConnectionString))
                {
                    SqlCommand command = new SqlCommand(_deleteQuery, connection);

                    command.Parameters.Add(new SqlParameter("@Id", id));

                    connection.Open();
                    return command.ExecuteNonQuery();
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new RepositoryException(e.Message);
            }
        }

        // The purose of these two methods is to declare the neccessary variables
        // to use in SQL commands

        private SqlParameter[] GenerateInsertSqlParameters(IRating rating)
        {
            var parameters = new[]
            {
                new SqlParameter("@Esrb", rating.Esrb),
                new SqlParameter("@ImagePath", rating.ImagePath)
            };
            return parameters;
        }

        private SqlParameter[] GenerateUpdateSqlParameters(IRating rating)
        {
            var parameters = new[]
            {
                new SqlParameter("@Id", rating.Id),
                new SqlParameter("@Esrb", rating.Esrb),
                new SqlParameter("@ImagePath", rating.ImagePath)
            };
            return parameters;
        }
    }
}
