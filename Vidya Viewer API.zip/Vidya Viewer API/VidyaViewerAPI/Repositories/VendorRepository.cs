﻿using System;
using System.Collections.Generic;
using VidyaViewerAPI.Models;
using VidyaViewerAPI.Models.Settings;
using System.Data.SqlClient;
using VidyaViewerAPI.Models.Exceptions;
using System.Data;
using VidyaViewerAPI.Extensions.Repository;

// Programmed by David Jones
// Third layer of API
// Purpose pass SQL statements to databse

namespace VidyaViewerAPI.Repositories
{
    public interface IVendorRepository
    {
        int Insert(IVendor vendor);

        IEnumerable<IVendor> GetListItems();

        IVendor GetById(int id);

        IEnumerable<IVendor> GetByGameId(int id);

        int Update(IVendor vendor);

        int Delete(int id);
    }

    public class VendorRepository : IVendorRepository
    {
        private string _insertQuery => @"
            INSERT INTO [dbo].[Vendor]
            (
                [VendorName],
                [Location],
                [DetailDescription],
                [ImagePath]
            ) 
            VALUES 
            (
                @VendorName,
                @Location,
                @DetailDescription,
                @ImagePath
            );
            SELECT CAST(SCOPE_IDENTITY() AS INT);";

        private string _getListItemsQuery =>
        @"
            SELECT
                VendorId AS Id,
                VendorName,
                Location,
                DetailDescription,
                ImagePath
            FROM Vendor
        ";

        private string _getByGameIdQuery =>
        @"
            SELECT
                Vendor.VendorId AS Id,
                VendorName,
                Location,
                DetailDescription,
                ImagePath
            FROM Vendor
            LEFT OUTER JOIN GameVendor ON Vendor.VendorId = GameVendor.VendorId
            WHERE GameId = @Id;
        ";

        private string _updateQuery =>
        @"
            UPDATE [dbo].[Vendor]
            SET VendorName = @VendorName,
                Location = @Location,
                DescriptionDetail = @DescriptionDetail,
                ImagePath = @ImagePath
            WHERE VendorId = @Id;
        ";

        private string _deleteQuery =>
        @"
            DELETE FROM [dbo].[Vendor]
            WHERE VendorId = @Id;
        ";

        private readonly IVidyaViewerAdoSettings _adoSettings;

        public VendorRepository(IVidyaViewerAdoSettings adoSettings)
        {
            _adoSettings = adoSettings;
        }

        public int Insert(IVendor vendor)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_adoSettings.ConnectionString))
                {
                    SqlCommand command = new SqlCommand(_insertQuery, connection);

                    foreach (SqlParameter sqlParameter in GenerateInsertSqlParameters(vendor))
                        command.Parameters.Add(sqlParameter);

                    connection.Open();
                    return (int)command.ExecuteScalar();
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new RepositoryException(e.Message);
            }
        }

        public IEnumerable<IVendor> GetListItems()
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection sqlConnection = new System.Data.SqlClient.SqlConnection(_adoSettings.ConnectionString))
                {
                    sqlConnection.Open();

                    using (SqlCommand command = new SqlCommand(_getListItemsQuery, sqlConnection))
                    using (IDataReader reader = command.ExecuteReader())
                    {
                        var listItems = new List<Vendor>();

                        while (reader.Read())
                        {
                            var listItem = new Vendor().PopulateVendor(reader);

                            listItems.Add(listItem);
                        }

                        return listItems;
                    }
                }
            }
            catch (Exception e)
            {
                throw (e);
            }
        }

        public IVendor GetById(int id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<IVendor> GetByGameId(int id)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection sqlConnection = new System.Data.SqlClient.SqlConnection(_adoSettings.ConnectionString))
                {
                    sqlConnection.Open();

                    using (SqlCommand command = new SqlCommand(_getByGameIdQuery, sqlConnection))
                    {
                        command.Parameters.Add(new SqlParameter("@Id", id));
                        using (IDataReader reader = command.ExecuteReader())
                        {
                            var vendors = new List<Vendor>();

                            while (reader.Read())
                            {
                                var vendor = new Vendor().PopulateVendor(reader);

                                vendors.Add(vendor);
                            }

                            return vendors;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                throw (e);
            }
        }

        public int Update(IVendor vendor)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_adoSettings.ConnectionString))
                {
                    SqlCommand command = new SqlCommand(_updateQuery, connection);

                    foreach (SqlParameter sqlParameter in GenerateUpdateSqlParameters(vendor))
                        command.Parameters.Add(sqlParameter);

                    connection.Open();
                    return command.ExecuteNonQuery();
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new RepositoryException(e.Message);
            }
        }

        public int Delete(int id)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_adoSettings.ConnectionString))
                {
                    SqlCommand command = new SqlCommand(_deleteQuery, connection);

                    command.Parameters.Add(new SqlParameter("@Id", id));

                    connection.Open();
                    return command.ExecuteNonQuery();
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new RepositoryException(e.Message);
            }
        }

        // The purose of these two methods is to declare the neccessary variables
        // to use in SQL commands

        private SqlParameter[] GenerateInsertSqlParameters(IVendor vendor)
        {
            var parameters = new[]
            {
                new SqlParameter("@VendorName", vendor.VendorName),
                new SqlParameter("@Location", vendor.Location),
                new SqlParameter("@DetailDescription", vendor.DetailDescription),
                new SqlParameter("@ImagePath", vendor.ImagePath)
            };
            return parameters;
        }

        private SqlParameter[] GenerateUpdateSqlParameters(IVendor vendor)
        {
            var parameters = new[]
            {
                new SqlParameter("@Id", vendor.Id),
                new SqlParameter("@VendorName", vendor.VendorName),
                new SqlParameter("@Location", vendor.Location),
                new SqlParameter("@DetailDescription", vendor.DetailDescription),
                new SqlParameter("@ImagePath", vendor.ImagePath)
            };
            return parameters;
        }
    }
}
