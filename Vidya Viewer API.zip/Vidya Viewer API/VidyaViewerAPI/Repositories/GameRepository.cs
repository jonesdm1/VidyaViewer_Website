﻿using System;
using System.Collections.Generic;
using VidyaViewerAPI.Models;
using VidyaViewerAPI.Models.Settings;
using System.Data.SqlClient;
using VidyaViewerAPI.Models.Exceptions;
using System.Data;
using VidyaViewerAPI.Extensions.Repository;

// Programmed by David Jones
// Third layer of API
// Purpose pass SQL statements to databse

namespace VidyaViewerAPI.Repositories
{
    public interface IGameRepository
    {
        // done
        int Insert(IGame game);

        // done
        IEnumerable<IGame> GetListItems();

        // done
        IGame GetGameById(int id);

        // done
        int Update(IGame game);

        // done
        int Delete(int id);
    }

    public class GameRepository : IGameRepository
    {
        // SQL statements
        private string _insertQuery => @"
            INSERT INTO [dbo].[Game]
            (
                [Title], 
                [RatingId],
                [ReleaseDate],
                [DescriptionDetail]
            ) 
            VALUES 
            (
                @Title,
                @RatingId,
                @ReleaseDate,
                @DescriptionDetail
            );
            SELECT CAST(SCOPE_IDENTITY() AS INT);";

        private string _getListItemsQuery =>
        @"
            SELECT
                GameId AS Id,
                Title,
                RatingId,
                ReleaseDate,
                DescriptionDetail,
                ImagePath
            FROM Game;
        ";

        private string _getByIdQuery =>
        @"
            SELECT
                GameId AS Id,
                Title,
                RatingId,
                ReleaseDate,
                DescriptionDetail,
                ImagePath
            FROM Game
            WHERE GameId = @Id;
        ";

        private string _updateQuery =>
        @"
            UPDATE [dbo].[Game]
            SET Title = @Title,
                RatingId = @RatingId,
                ReleaseDate = @ReleaseDate,
                DescriptionDetail = @DescriptionDetail,
                ImagePath = @ImagePath
            WHERE GameId = @Id;
        ";

        private string _deleteQuery =>
        @"
            DELETE FROM [dbo].[Game]
            WHERE GameId = @Id;
        ";

        private readonly IVidyaViewerAdoSettings _adoSettings;

        public GameRepository(IVidyaViewerAdoSettings adoSettings)
        {
            _adoSettings = adoSettings;
        }

        // Insert new Game
        public int Insert(IGame game)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_adoSettings.ConnectionString))
                {
                    SqlCommand command = new SqlCommand(_insertQuery, connection);

                    foreach (SqlParameter sqlParameter in GenerateInsertSqlParameters(game))
                        command.Parameters.Add(sqlParameter);

                    connection.Open();
                    return (int)command.ExecuteScalar();
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new RepositoryException(e.Message);
            }
        }

        // Get list of Games
        public IEnumerable<IGame> GetListItems()
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection sqlConnection = new System.Data.SqlClient.SqlConnection(_adoSettings.ConnectionString))
                {
                    sqlConnection.Open();

                    using (SqlCommand command = new SqlCommand(_getListItemsQuery, sqlConnection))
                    using (IDataReader reader = command.ExecuteReader())
                    {
                        var listItems = new List<Game>();

                        while (reader.Read())
                        {
                            var listItem = new Game().PopulateGame(reader);

                            listItems.Add(listItem);
                        }

                        return listItems;
                    }
                }
            }
            catch (Exception e)
            {
                throw (e);
            }
        }

        // Get Game Details by Id
        public IGame GetGameById(int id)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection sqlConnection = new System.Data.SqlClient.SqlConnection(_adoSettings.ConnectionString))
                {
                    sqlConnection.Open();

                    using (SqlCommand command = new SqlCommand(_getByIdQuery, sqlConnection))
                    {
                        command.Parameters.Add(new SqlParameter("@Id", id));
                        using (IDataReader reader = command.ExecuteReader())
                        {
                            var gameDetail = new Game();

                            if (reader.Read())
                            {
                                gameDetail = new Game().PopulateGame(reader);
                            }
                            return gameDetail;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                throw (e);
            }
        }

        public int Update(IGame game)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_adoSettings.ConnectionString))
                {
                    SqlCommand command = new SqlCommand(_updateQuery, connection);

                    foreach (SqlParameter sqlParameter in GenerateUpdateSqlParameters(game))
                        command.Parameters.Add(sqlParameter);

                    connection.Open();
                    return command.ExecuteNonQuery();
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new RepositoryException(e.Message);
            }
        }

        public int Delete(int id)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_adoSettings.ConnectionString))
                {
                    SqlCommand command = new SqlCommand(_deleteQuery, connection);

                    command.Parameters.Add(new SqlParameter("@Id", id));

                    connection.Open();
                    return command.ExecuteNonQuery();
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new RepositoryException(e.Message);
            }
        }

        // The purose of these two methods is to declare the neccessary variables
        // to use in SQL commands

        private SqlParameter[] GenerateInsertSqlParameters(IGame game)
        {
            var parameters = new[]
            {
                new SqlParameter("@Title", game.Title),
                new SqlParameter("@RatingId", game.RatingId),
                new SqlParameter("@ReleaseDate", game.ReleaseDate),
                new SqlParameter("@DescriptionDetail", game.DescriptionDetail),
                new SqlParameter("@ImagePath", game.ImagePath)
            };
            return parameters;
        }

        private SqlParameter[] GenerateUpdateSqlParameters(IGame game)
        {
            var parameters = new[]
            {
                new SqlParameter("@Id", game.Id),
                new SqlParameter("@Title", game.Title),
                new SqlParameter("@RatingId", game.RatingId),
                new SqlParameter("@ReleaseDate", game.ReleaseDate),
                new SqlParameter("@DescriptionDetail", game.DescriptionDetail),
                new SqlParameter("@ImagePath", game.ImagePath)
            };
            return parameters;
        }
    }
}
