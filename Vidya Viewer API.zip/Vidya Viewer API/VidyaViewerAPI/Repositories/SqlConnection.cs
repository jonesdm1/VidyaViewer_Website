﻿using System;

namespace VidyaViewerAPI.Repositories
{
    internal class SqlConnection
    {
        private string _connectionString;

        public SqlConnection(string connectionString)
        {
            _connectionString = connectionString;
        }

        internal void Open()
        {
            throw new NotImplementedException();
        }
    }
}