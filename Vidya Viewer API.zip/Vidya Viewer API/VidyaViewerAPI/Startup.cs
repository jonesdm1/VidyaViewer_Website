using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using VidyaViewerAPI.Models.Settings;
using VidyaViewerAPI.Processors;
using VidyaViewerAPI.Repositories;

namespace VidyaViewerAPI
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            var clientSettings = new AdoClientSettings();
            Configuration.GetSection("ClientSettings").Bind(clientSettings);

            services.AddOptions()
                .AddSingleton<IVidyaViewerAdoSettings>(clientSettings.VidyaViewerAdoSettings)
                .AddTransient<IDeveloperProcessor, DeveloperProcessor>()
                .AddTransient<IGameProcessor, GameProcessor>()
                .AddTransient<IGenreProcessor, GenreProcessor>()
                .AddTransient<IRatingProcessor, RatingProcessor>()
                .AddTransient<IVendorProcessor, VendorProcessor>()
                .AddTransient<IDeveloperRepository, DeveloperRepository>()
                .AddTransient<IGameDeveloperRepository, GameDeveloperRepository>()
                .AddTransient<IGameRepository, GameRepository>()
                .AddTransient<IGenreRepository, GenreRepository>()
                .AddTransient<IRatingRepository, RatingRepository>()
                .AddTransient<IVendorRepository, VendorRepository>();

            services.AddControllers();

            string corsDomains = "http://localhost:4200";

            string[] domains = corsDomains.Split(",".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
            services.AddCors(o => o.AddPolicy("AppCORSPolicy", builder =>
            {
                builder.AllowAnyOrigin()
                       .AllowAnyMethod()
                       .AllowAnyHeader()
                       .AllowCredentials()
                       .WithOrigins(domains);
            }));
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseCors("AppCORSPolicy");

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
