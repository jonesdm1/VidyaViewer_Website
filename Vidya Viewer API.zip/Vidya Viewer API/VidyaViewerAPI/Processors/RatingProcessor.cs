﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using VidyaViewerAPI.Models;
using VidyaViewerAPI.Models.Exceptions;
using VidyaViewerAPI.Repositories;

// Programmed by David Jones
// Purpose call Repositories

namespace VidyaViewerAPI.Processors
{
    public interface IRatingProcessor
    {
        // done
        IRating Insert(IRating rating);

        // done
        IEnumerable<IRating> GetListItems();

        // not done
        IRating GetById(int id);

        // done
        IRating Update(IRating rating);

        // done
        string Delete(int id);
    }

    public class RatingProcessor : IRatingProcessor
    {
        private readonly IRatingRepository _ratingRepository;

        public RatingProcessor(IRatingRepository ratingRepository)
        {
            _ratingRepository = ratingRepository;
        }

        public IRating Insert(IRating rating)
        {
            try
            {
                rating.Id = _ratingRepository.Insert(rating);

                if (rating.Id < 1)
                {
                    throw new Exception("Failed to create Rating.");
                }
                return rating;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (RepositoryException)
            {
                throw;
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new ProcessorException(e.Message);
            }
        }

        public IEnumerable<IRating> GetListItems()
        {
            try
            {
                return _ratingRepository.GetListItems();
            }
            catch (SqlException)
            {
                throw;
            }
            catch (RepositoryException)
            {
                throw;
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new ProcessorException(e.Message);
            }
        }

        public IRating GetById(int id)
        {
            try
            {
                return _ratingRepository.GetByGameId(id);
            }
            catch (SqlException)
            {
                throw;
            }
            catch (RepositoryException)
            {
                throw;
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new ProcessorException(e.Message);
            }
        }

        public IRating Update(IRating rating)
        {
            try
            {
                int rows = _ratingRepository.Update(rating);

                if (rows < 1)
                {
                    throw new Exception("Failed to edit Rating.");
                }
                return rating;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (RepositoryException)
            {
                throw;
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new ProcessorException(e.Message);
            }
        }

        public string Delete(int id)
        {
            try
            {
                int rows = _ratingRepository.Delete(id);

                if (rows < 1)
                {
                    throw new Exception("Failed to Delete Rating.");
                }
                else
                {
                    return "Succeeded in Deleting Rating.";
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (RepositoryException)
            {
                throw;
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new ProcessorException(e.Message);
            }
        }
    }
}
