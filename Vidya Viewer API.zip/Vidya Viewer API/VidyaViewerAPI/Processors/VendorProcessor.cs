﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using VidyaViewerAPI.Models;
using VidyaViewerAPI.Models.Exceptions;
using VidyaViewerAPI.Repositories;

// Programmed by David Jones
// Purpose call Repositories

namespace VidyaViewerAPI.Processors
{
    public interface IVendorProcessor
    {
        // done
        IVendor Insert(IVendor vendor);

        // done
        IEnumerable<IVendor> GetListItems();

        // not done
        IVendor GetById(int id);

        // done
        IVendor Update(IVendor vendor);

        // done
        string Delete(int id);
    }

    public class VendorProcessor : IVendorProcessor
    {
        private readonly IVendorRepository _vendorRepository;

        public VendorProcessor(IVendorRepository vendorRepository)
        {
            _vendorRepository = vendorRepository;
        }

        public IVendor Insert(IVendor vendor)
        {
            try
            {
                vendor.Id = _vendorRepository.Insert(vendor);

                if (vendor.Id < 1)
                {
                    throw new Exception("Failed to create Vendor.");
                }
                return vendor;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (RepositoryException)
            {
                throw;
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new ProcessorException(e.Message);
            }
        }

        public IEnumerable<IVendor> GetListItems()
        {
            try
            {
                return _vendorRepository.GetListItems();
            }
            catch (SqlException)
            {
                throw;
            }
            catch (RepositoryException)
            {
                throw;
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new ProcessorException(e.Message);
            }
        }

        public IVendor GetById(int id)
        {
            throw new NotImplementedException();
        }

        public IVendor Update(IVendor vendor)
        {
            try
            {
                int rows = _vendorRepository.Update(vendor);

                if (rows < 1)
                {
                    throw new Exception("Failed to edit Vendor.");
                }
                return vendor;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (RepositoryException)
            {
                throw;
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new ProcessorException(e.Message);
            }
        }

        public string Delete(int id)
        {
            try
            {
                int rows = _vendorRepository.Delete(id);

                if (rows < 1)
                {
                    throw new Exception("Failed to Delete Vendor.");
                }
                else
                {
                    return "Succeeded in Deleting Vendor.";
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (RepositoryException)
            {
                throw;
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new ProcessorException(e.Message);
            }
        }
    }
}
