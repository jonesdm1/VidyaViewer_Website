﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using VidyaViewerAPI.Models;
using VidyaViewerAPI.Models.Exceptions;
using VidyaViewerAPI.Repositories;

// Programmed by David Jones
// Purpose call Repositories

namespace VidyaViewerAPI.Processors
{
    public interface IGameProcessor
    {
        IGame Insert(IGame game);

        IEnumerable<IGame> GetListItems();

        IGamePackage GetGameDetails(int id);

        IGame Update(IGame game);

        string Delete(int id);
    }

    public class GameProcessor : IGameProcessor
    {
        private readonly IDeveloperRepository _developerRepository;
        private readonly IGameRepository _gameRepository;
        private readonly IGenreRepository _genreRepository;
        private readonly IRatingRepository _ratingRepository;
        private readonly IVendorRepository _vendorRepository;

        // Creates all repository objects gamePackage
        public GameProcessor(IDeveloperRepository developerRepository, 
                             IGameRepository gameRepository, IGenreRepository genreRepository,
                             IRatingRepository ratingRepository, IVendorRepository vendorRepository)
        {
            _developerRepository = developerRepository;
            _gameRepository = gameRepository;
            _genreRepository = genreRepository;
            _ratingRepository = ratingRepository;
            _vendorRepository = vendorRepository;
        }

        public IGame Insert(IGame game)
        {
            try
            {
                game.Id = _gameRepository.Insert(game);

                // If number of rows affected is 0, no game was created and an exception is thrown
                if (game.Id < 1)
                {
                    throw new Exception("Failed to create Game.");
                }

                return game;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (RepositoryException)
            {
                throw;
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new ProcessorException(e.Message);
            }
        }

        // Get all Games
        public IEnumerable<IGame> GetListItems()
        {
            return _gameRepository.GetListItems();
        }

        // The purpose of this method is to compile data into an object (GamePackage)
        // of objects. It is used for the individual pages of games so that vendors,
        // developers, genres, and rating of a certain game can be used to post to the
        // game-description page. Which is why the id of that game is past into the method.
        public IGamePackage GetGameDetails(int id)
        {
            try
            {
                return new GamePackage()
                {
                    Game = _gameRepository.GetGameById(id),
                    Vendors = _vendorRepository.GetByGameId(id),
                    Developers = _developerRepository.GetGameDetails(id),
                    Genres = _genreRepository.GetGameDetails(id),
                    Rating = _ratingRepository.GetByGameId(id)
                };
            }
            catch (SqlException)
            {
                throw;
            }
            catch (RepositoryException)
            {
                throw;
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new ProcessorException(e.Message);
            }
        }

        // Update Game
        // A new game is past into the repository afterwhich the same one is return to the front end to immediately
        // update the Game Table on admin
        public IGame Update(IGame game)
        {
            try
            {
                int rows = _gameRepository.Update(game);

                if (rows < 1)
                {
                    throw new Exception("Failed to edit Game.");
                }
                return game;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (RepositoryException)
            {
                throw;
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new ProcessorException(e.Message);
            }
        }

        public string Delete(int id)
        {
            try
            {
                int rows = _gameRepository.Delete(id);

                if (rows < 1)
                {
                    throw new Exception("Failed to Delete Game.");
                }
                else
                {
                    return "Succeeded in Deleting Game.";
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (RepositoryException)
            {
                throw;
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new ProcessorException(e.Message);
            }
        }
    }
}
