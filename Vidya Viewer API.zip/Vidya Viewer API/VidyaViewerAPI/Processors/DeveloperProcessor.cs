﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using VidyaViewerAPI.Models;
using VidyaViewerAPI.Models.Exceptions;
using VidyaViewerAPI.Repositories;

// Programmed by David Jones
// Purpose call Repositories

namespace VidyaViewerAPI.Processors
{
    public interface IDeveloperProcessor
    {
        IDeveloper Insert(IDeveloper developer);

        IEnumerable<IDeveloper> GetListItems();

        IDeveloper GetById(int id);

        IDeveloper Update(IDeveloper developer);

        string Delete(int id);
    }

    public class DeveloperProcessor : IDeveloperProcessor
    {
        private readonly IDeveloperRepository _developerRepository;

        public DeveloperProcessor(IDeveloperRepository developerRepository)
        {
            _developerRepository = developerRepository;
        }

        public IDeveloper Insert(IDeveloper developer)
        {
            try
            {
                developer.Id = _developerRepository.Insert(developer);

                if (developer.Id < 1)
                {
                    throw new Exception("Failed to create Developer.");
                }
                return developer;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (RepositoryException)
            {
                throw;
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new ProcessorException(e.Message);
            }
        }

        public IEnumerable<IDeveloper> GetListItems()
        {
            try
            {
                return _developerRepository.GetListItems();
            }
            catch (SqlException)
            {
                throw;
            }
            catch (RepositoryException)
            {
                throw;
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new ProcessorException(e.Message);
            }
        }

        public IDeveloper GetById(int id)
        {
            try
            {
                return _developerRepository.GetById(id);
            }
            catch (SqlException)
            {
                throw;
            }
            catch (RepositoryException)
            {
                throw;
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new ProcessorException(e.Message);
            }
        }

        public IDeveloper Update(IDeveloper developer)
        {
            try
            {
                int rows = _developerRepository.Update(developer);

                if (rows < 1)
                {
                    throw new Exception("Failed to edit Game.");
                }
                return developer;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (RepositoryException)
            {
                throw;
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new ProcessorException(e.Message);
            }
        }

        public string Delete(int id)
        {
            try
            {
                int rows = _developerRepository.Delete(id);

                if (rows < 1)
                {
                    throw new Exception("Failed to Delete Game.");
                }
                else
                {
                    return "Succeeded in Deleting Game.";
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (RepositoryException)
            {
                throw;
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new ProcessorException(e.Message);
            }
        }
    }
}
