﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using VidyaViewerAPI.Models;
using VidyaViewerAPI.Models.Exceptions;
using VidyaViewerAPI.Repositories;

// Programmed by David Jones
// Purpose call Repositories

namespace VidyaViewerAPI.Processors
{
    public interface IGenreProcessor
    {
        // done
        IGenre Insert(IGenre genre);

        // done
        IEnumerable<IGenre> GetListItems();

        // not done
        IGenre GetById(int id);

        // done
        IGenre Update(IGenre genre);

        // done
        string Delete(int id);
    }
    public class GenreProcessor : IGenreProcessor
    {
        private readonly IGenreRepository _genreRepository;

        public GenreProcessor(IGenreRepository genreRepository)
        {
            _genreRepository = genreRepository;
        }

        public IGenre Insert(IGenre genre)
        {
            try
            {
                genre.Id = _genreRepository.Insert(genre);

                if (genre.Id < 1)
                {
                    throw new Exception("Failed to create Developer.");
                }
                return genre;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (RepositoryException)
            {
                throw;
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new ProcessorException(e.Message);
            }
        }

        public IEnumerable<IGenre> GetListItems()
        {
            try
            {
                return _genreRepository.GetListItems();
            }
            catch (SqlException)
            {
                throw;
            }
            catch (RepositoryException)
            {
                throw;
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new ProcessorException(e.Message);
            }
        }

        public IGenre GetById(int id)
        {
            try
            {
                return _genreRepository.GetById(id);
            }
            catch (SqlException)
            {
                throw;
            }
            catch (RepositoryException)
            {
                throw;
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new ProcessorException(e.Message);
            }
        }

        public IGenre Update(IGenre genre)
            {
            try
            {
                int rows = _genreRepository.Update(genre);

                if (rows < 1)
                {
                    throw new Exception("Failed to edit Game.");
                }
                return genre;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (RepositoryException)
            {
                throw;
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new ProcessorException(e.Message);
            }
        }

        public string Delete(int id)
        {
            try
            {
                int rows = _genreRepository.Delete(id);

                if (rows < 1)
                {
                    throw new Exception("Failed to Delete Game.");
                }
                else
                {
                    return "Succeeded in Deleting Game.";
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (RepositoryException)
            {
                throw;
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new ProcessorException(e.Message);
            }
        }
    }
}
